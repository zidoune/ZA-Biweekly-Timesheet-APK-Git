ZA Biweekly Timesheet Android launcher icon assets

Contents include density-specific legacy launcher PNGs, an adaptive icon XML,
a foreground image, and a background color resource.

Copy the resources into the Android app module's res/ directory, replacing matching
launcher icon files. Confirm AndroidManifest.xml uses android:icon="@mipmap/ic_launcher"
(and roundIcon if present) before building the APK.
